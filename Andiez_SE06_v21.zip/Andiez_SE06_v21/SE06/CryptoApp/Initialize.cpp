#include "Initialize.h"

TCHAR szFileName[MAX_PATH] = { 0 };
TCHAR szFileNameIn[MAX_PATH] = { 0 };
TCHAR szFileNameOut[MAX_PATH] = { 0 };
BYTE szKey[MAX_PATH] = { 0 };