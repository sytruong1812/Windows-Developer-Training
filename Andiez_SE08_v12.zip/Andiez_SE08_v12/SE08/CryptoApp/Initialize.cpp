#include "Initialize.h"

BYTE szKey[MAX_PATH] = { 0 };

TCHAR szFileName[MAX_PATH] = { 0 };
TCHAR szFileNameIn[MAX_PATH] = { 0 };
TCHAR szFileNameOut[MAX_PATH] = { 0 };
TCHAR pathApp[MAX_PATH] = { 0 };
