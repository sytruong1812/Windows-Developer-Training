﻿#pragma once
#include "RTFTag.h"
#include "RTFText.h"
#include "RTFColor.h"

class RTFGroup
{
private:
	int num;
	string name;
	map<string, int> attributes;
public:
	vector<RTFGroup> subGroups;

	RTFGroup(string name);
	RTFGroup(string name, int num);

	string getGroupName() const;
	int getNumOfGroup() const;
	void addSubGroup(const RTFGroup& group);
	const vector<RTFGroup>& getSubGroups() const;
	void addAttribute(const string& key, int value);
	int getAttribute(const string& key) const;

};

