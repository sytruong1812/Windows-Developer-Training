﻿#include "RTFParse.h"

using namespace std;

RDS rds;
RIS ris;

RTFParse::RTFParse()
{
	this->nGroup = 0;
	this->state = STATE::Norm;
	this->myGroup = new RTFGroup("Root");
}

RTFParse::~RTFParse()
{
	if (this->myGroup != nullptr) {
		delete this->myGroup;
		this->myGroup = nullptr;
	}
}

bool RTFParse::Parse(const BYTE* buffer, size_t size)
{
	size_t index = 0;
	char ch;
	while (index < size) {
		ch = buffer[index++];
		if (nGroup < 0) {
			return false;
		}
		switch (ch) {
		case '{':
			if (!pushRtfState()) {
				return false;
			}
			break;
		case '}':
			if (!popRtfState()) {
				return false;
			}
			break;
		case '\\':
			if (!parseKeyword(buffer, size, index)) {
				return false;
			}
			break;
		case 0x0d:		//CR: Đưa con trỏ về đầu dòng mà không thay đổi hàng.
		case 0x0a:		//LB: Thực hiện việc chuyển xuống hàng mới.
			break;
		default:
			//TODO: Xử lý save content, phải xử lý không được lưu các content trong các table
			if (rds == rdsNorm) {
				cout << ch;
				//saveText(string(&ch));
			}
			break;
		}
	}
	if (nGroup < 0) {
		return false;
	}
	if (nGroup > 0) {
		return false;
	}
	if (index == size) {
		cout << endl;
		showKeyword(ctrlwords);
	}
	return true;
}

bool RTFParse::pushRtfState()
{
	SAVE* pSaveNew = new SAVE;
	if (!pSaveNew) {
		return false;
	}
	pSaveNew->pNext = pSave;

	pSaveNew->rds = rds;
	pSaveNew->ris = ris;

	pSave = pSaveNew;
	nGroup++;
	return true;
}

bool RTFParse::popRtfState()
{
	SAVE* pSaveOld;
	if (!pSave) {
		return false;
	}
	if (rds != pSave->rds) {
		//TODO: Handle when exit a group (eg: save fonttbl)
		state = STATE::Norm;
	}
	rds = pSave->rds;
	ris = pSave->ris;

	pSaveOld = pSave;
	pSave = pSave->pNext;
	nGroup--;
	delete(pSaveOld);
	return true;
}

bool RTFParse::parseKeyword(const BYTE* buffer, size_t& size, size_t& index)
{
	char ch = buffer[index++];
	char szKeyword[30];
	int param = 0;
	bool fParam = false;
	char szParameter[20];
	bool fNeg = false;
	char* pch = nullptr;
	char* pParamMax = &szParameter[20];
	szKeyword[0] = '\0';
	szParameter[0] = '\0';

	if (index >= size) {
		return false;
	}
	if (!isalpha(ch)) {
		szKeyword[0] = ch;
		szKeyword[1] = '\0';
		return translateKeyword(szKeyword, 0, fParam);
	}
	// Get keyword: Gán ký tự vào mảng szKeyword và dịch con trỏ pch tới vị trí tiếp theo
	for (pch = szKeyword; pch < szKeyword + 30 && isalpha(ch); ch = buffer[index++]) {
		*pch++ = ch;
		if (index >= size) {
			return false;
		}
	}
	if (pch >= szKeyword + 30) {
		return false;
	}
	*pch = '\0';
	if (ch == '-') {
		fNeg = true;
		ch = buffer[index++];
		if (index >= size) {
			return false;
		}
	}
	// Get param
	if (isdigit(ch)) {
		fParam = true;
		// Gán param vào mảng szParameter và dịch con trỏ pch tới vị trí tiếp theo
		for (pch = szParameter; pch < pParamMax && isdigit(ch); ch = buffer[index++]) {
			*pch++ = ch;
			if (index >= size) {
				return false;
			}
		}
		if (pch >= pParamMax) {
			return false;
		}
		*pch = '\0';
		param = atoi(szParameter);
		if (fNeg) {
			param = -param;
		}
	}
	if (ch != ' ') {
		index--;
	}
	return translateKeyword(szKeyword, param, fParam);
}

//TODO: Phần này phải tách được các loại Control Word theo bảng RTF_CTRLWORDS và lưu lại
bool RTFParse::translateKeyword(char* szKeyword, int param, bool fParam)
{
	bool found = false;
	ControlType isym;
	for (const auto& pair : TABLE_CTRLWORDS) {
		if (strcmp(szKeyword, pair.first.c_str()) == 0) {
			//saveKeyword(szKeyword, param, fParam);
			handleRTFInternal(szKeyword, param, fParam);
			isym = pair.second;
			found = true;
			break;
		}
	}
	if (!found) {
		isym = ControlType::Skip;
	}

	switch (isym)
	{
	case ControlType::Flag:
		break;
	case ControlType::Destination:
		if (!strcmp(szKeyword, "rtf") == 0) {
			rds = rdsSkip;
			handleRTFDestination(szKeyword, param, fParam);
		}
		break;
	case ControlType::Symbol:
		break;
	case ControlType::Toggle:
		break;
	case ControlType::Value:
		break;
	case ControlType::NF:
		rds = rdsSkip;
		break;
	case ControlType::Skip:
		break;
	default:
		break;
	}
	return true;
}

//TODO: Processing here.... Handle RTF Destination
void RTFParse::handleRTFDestination(char* szKeyword, int param, bool fParam)
{
	if (strcmp(szKeyword, "fonttbl") == 0) {
		state = STATE::Fonttbl;
		auto fonttbl = new RTFGroup(szKeyword);		//{\fonttbl
		myGroup->addSubGroup(*fonttbl);
	}
	else if (strcmp(szKeyword, "colortbl") == 0) {
		state = STATE::Colortbl;
		auto colortbl = new RTFGroup(szKeyword);
		myGroup->addSubGroup(*colortbl);
	}
	else {

	}
}

void RTFParse::handleRTFInternal(char* szKeyword, int param, bool fParam)
{
	static int i = 0;
	switch (state) {
	case STATE::Norm:
		myGroup->addAttribute(szKeyword, param);
		break;
	case STATE::Fonttbl:
		if (strcmp(szKeyword, "f") == 0) {
			auto subGroupFont = new RTFGroup(string(szKeyword) + to_string(param), param);
			myGroup->subGroups[0].addSubGroup(*subGroupFont);
			break;
		}
		myGroup->subGroups[0].addAttribute(szKeyword, param);
		break;
	case STATE::Colortbl:
		if (strcmp(szKeyword, "red") == 0) {
			auto subGroupColor = new RTFGroup(string(szKeyword) + to_string(param), i++);
			myGroup->subGroups[1].addSubGroup(*subGroupColor);
			break;
		}
		myGroup->subGroups[1].addAttribute(szKeyword, param);
		break;
	default:

		break;
	}
}

