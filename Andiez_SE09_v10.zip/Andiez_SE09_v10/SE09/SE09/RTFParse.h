#pragma once
#include "RTFGroup.h"

class RTFParse : public RTFTag
{
private:
	int nGroup;
	STATE state;
	SAVE* pSave = nullptr;
	RTFGroup* myGroup = nullptr;
public:
	RTFParse();
	~RTFParse();
	bool Parse(const BYTE* buffer, size_t size);
	bool pushRtfState();
	bool popRtfState();
	bool parseKeyword(const BYTE* buffer, size_t& size, size_t& index);
	bool translateKeyword(char* szKeyword, int param, bool fParam);
	void handleRTFDestination(char* szKeyword, int param, bool fParam);
	void handleRTFInternal(char* szKeyword, int param, bool fParam);
};