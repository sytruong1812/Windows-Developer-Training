﻿#include "RTFGroup.h"

RTFGroup::RTFGroup(string name)
{
	this->name = name;
}

RTFGroup::RTFGroup(string name, int num)
{
	this->name = name;
	this->num = num;
}

void RTFGroup::addAttribute(const string& key, int value)
{
	attributes[key] = value;
}

int RTFGroup::getAttribute(const string& key) const
{
	auto it = attributes.find(key);
	if (it != attributes.end()) {
		return it->second;
	}
	return 0;
}

void RTFGroup::addSubGroup(const RTFGroup& group)
{
	subGroups.push_back(group);
}

string RTFGroup::getGroupName() const
{
	return name;
}

int RTFGroup::getNumOfGroup() const
{
	return num;
}

const vector<RTFGroup>& RTFGroup::getSubGroups() const
{
	return subGroups;
}