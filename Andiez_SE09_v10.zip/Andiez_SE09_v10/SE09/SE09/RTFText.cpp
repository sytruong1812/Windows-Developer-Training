#include "RTFText.h"

void RTFText::saveText(string text)
{
	content.push_back(text);
}
