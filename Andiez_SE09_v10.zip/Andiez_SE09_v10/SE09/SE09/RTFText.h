#pragma once
#include "RTFType.h"

class RTFText
{
protected:
	vector<string> content;
public:
	void saveText(string text);
};

