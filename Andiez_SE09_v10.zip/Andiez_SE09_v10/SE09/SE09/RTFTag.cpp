﻿#include "RTFTag.h"

void RTFTag::saveKeyword(char* szKeyword, int param, bool fParam)
{
	ctrlword.keyword = szKeyword;
	ctrlword.param = param;
	ctrlword.fParam = fParam;
	ctrlwords.push_back(ctrlword);
}

const vector<CTRLWORD>& RTFTag::getKeyword()
{
	return ctrlwords;
}

void RTFTag::showKeyword(const vector<CTRLWORD>& ctrlwords)
{
	for (const CTRLWORD& ctrl : ctrlwords) {
		cout << "Keyword: " << ctrl.keyword
			<< " | Param: " << ctrl.param
			<< " | fParam: " << (ctrl.fParam ? "True" : "False")
			<< endl;
	}
}

