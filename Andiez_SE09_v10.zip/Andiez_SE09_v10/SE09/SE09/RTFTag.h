#pragma once
#include "RTFType.h"
class RTFTag
{
private:
	CTRLWORD ctrlword;
protected:
	vector<CTRLWORD> ctrlwords;
public: 
	void saveKeyword(char* szKeyword, int param, bool fParam);
	const vector<CTRLWORD>& getKeyword();
	void showKeyword(const vector<CTRLWORD>& ctrlwords);
};