﻿#pragma once
#include "RTFType.h"
#include "RTFCtrlWord.h"
#include "RTFText.h"
#include "RTFColor.h"

class RTFGroup : public RTFCtrlWord, public RTFText
{
protected:
	SAVE* hSave;
	int nGroup;
public:
	bool startGroup();
	bool endGroup();
};

