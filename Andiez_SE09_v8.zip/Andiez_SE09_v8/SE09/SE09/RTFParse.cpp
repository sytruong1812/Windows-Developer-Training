﻿#include "RTFParse.h"

using namespace std;

RTFParse::RTFParse()
{
	this->nGroup = 0;
}

bool RTFParse::Parse(const unsigned char* buffer, size_t size)
{
	size_t index = 0;
	char ch;
	while (index < size) {
		ch = buffer[index++];
		if (nGroup < 0) {
			return false;
		}
		switch (ch) {
		case '{':
			if (!startGroup()) {
				return false;
			}
			break;
		case '}':
			if (!endGroup()) {
				return false;
			}
			break;
		case '\\':
			if (!parseKeyword(buffer, size, index)) {
				return false;
			}
			break;
		case 0x0d:		//CR: Đưa con trỏ về đầu dòng mà không thay đổi hàng.
		case 0x0a:		//LB: Thực hiện việc chuyển xuống hàng mới.
			break;
		default:
			//TODO: Xử lý save content, phải xử lý không được lưu các content trong các table
			if (rds == rdsNorm) {
				cout << ch;
				//saveText(string(&ch));
			}
			break;
		}
	}
	if (nGroup < 0) {
		return false;
	}
	if (nGroup > 0) {
		return false;
	}
	if (index == size) {
		cout << endl;
		cout << "-------------------------------------------" << endl;
		showKeyword(ctrlwords);
	}
	return true;
}
