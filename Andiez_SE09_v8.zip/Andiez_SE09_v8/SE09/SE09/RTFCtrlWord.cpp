﻿#include <ctype.h>
#include <iostream>
#include "RTFCtrlWord.h"

void RTFCtrlWord::saveKeyword(char* szKeyword, int param, bool fParam)
{
	ctrlword.keyword = szKeyword;
	ctrlword.param = param;
	ctrlword.fParam = fParam;
	ctrlwords.push_back(ctrlword);
}

void RTFCtrlWord::showKeyword(const vector<CTRLWORD>& ctrlwords)
{
	for (const CTRLWORD& ctrl : ctrlwords) {
		cout << "Keyword: " << ctrl.keyword
			<< " | Param: " << ctrl.param
			<< " | fParam: " << (ctrl.fParam ? "True" : "False")
			<< endl;
	}
}

bool RTFCtrlWord::parseKeyword(const unsigned char* buffer, size_t &size, size_t &index)
{
	char ch = buffer[index++];
	char szKeyword[30];
	int param = 0;
	bool fParam = false;
	char szParameter[20];
	bool fNeg = false;
	char* pch = nullptr;
	char* pParamMax = &szParameter[20];
	szKeyword[0] = '\0';
	szParameter[0] = '\0';

	if (index >= size) {
		return false;
	}
	if (!isalpha(ch)) {	
		szKeyword[0] = ch;
		szKeyword[1] = '\0';
		return translateKeyword(szKeyword, 0, fParam);
	}

	// Get keyword: Gán ký tự vào mảng szKeyword và dịch con trỏ pch tới vị trí tiếp theo
	for (pch = szKeyword; pch < szKeyword + 30 && isalpha(ch); ch = buffer[index++]) {
		*pch++ = ch;
		if (index >= size) {
			return false;
		}
	}
	if (pch >= szKeyword + 30) {
		return false;
	}
	*pch = '\0';
	if (ch == '-') {
		fNeg = true;
		ch = buffer[index++];
		if (index >= size) {
			return false;
		}
	}
	// Get param
	if (isdigit(ch)) {
		fParam = true;
		// Gán param vào mảng szParameter và dịch con trỏ pch tới vị trí tiếp theo
		for (pch = szParameter; pch < pParamMax && isdigit(ch); ch = buffer[index++]) {
			*pch++ = ch;
			if (index >= size) {
				return false;
			}
		}
		if (pch >= pParamMax) {
			return false;
		}
		*pch = '\0';
		param = atoi(szParameter);
		if (fNeg) {
			param = -param;
		}
	}
	if (ch != ' ') {
		index--;
	}
	return translateKeyword(szKeyword, param, fParam);
}

//TODO: Phần này phải tách được các loại Control Word theo bảng RTF_CTRLWORDS và lưu lại
bool RTFCtrlWord::translateKeyword(char* szKeyword, int param, bool fParam)
{
	bool found = false;
	ControlType isym;
	for (const auto& pair : TABLE_CTRLWORDS) {
		if (strcmp(szKeyword, pair.first.c_str()) == 0) {
			saveKeyword(szKeyword, param, fParam);
			isym = pair.second;
			found = true;
			break;
		}
	}
	if (!found) {
		isym = ControlType::Skip;
	}
	switch (isym)
	{
	case ControlType::Flag:
		break;
	case ControlType::Destination:	
		rds = rdsSkip;
		translateTable(szKeyword, param, fParam);	
		break;
	case ControlType::Symbol:
		break;
	case ControlType::Toggle:
		break;
	case ControlType::Value:
		break;
	case ControlType::Special:
		rds = rdsNorm;
		break;
	case ControlType::Skip:
		break;
	default:
		break;
	}
	return true;
}

//TODO: Processing here.... Handle RTF Destination
void RTFCtrlWord::translateTable(char* szKeyword, int param, bool fParam)
{
	if (strcmp(szKeyword, "fonttbl") == 0) {
		// Xử lý fonttbl
	}
	else if (strcmp(szKeyword, "colortbl") == 0) {
		// Xử lý colortbl
	}
	else {
		
	}
}
