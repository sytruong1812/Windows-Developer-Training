﻿#pragma once
#include <iostream>
#include <vector>
#include <string> 
#include <map>

using namespace std;

/*
Enum: FontFamily
Description: Represents font families in RTF.
*/

typedef enum
{
	FNIL,        // Unknown or default fonts (the default)
	FROMAN,      // Roman, proportionally spaced serif fonts (e.g., Times New Roman, Palatino)
	FSWISS,      // Swiss, proportionally spaced sans serif fonts (e.g., Arial)
	FMODERN,     // Fixed-pitch serif and sans serif fonts (e.g., Courier New, Pica)
	FSCRIPT,     // Script fonts (e.g., Cursive)
	FDECOR,      // Decorative fonts (e.g., Old English, ITC Zapf Chancery)
	FTECH,       // Technical, symbol, and mathematical fonts (e.g., Symbol)
	FBIDI,       // Arabic, Hebrew, or other bidirectional font (e.g., Miriam)
} FontFamily;


/*
Enum: CodePage
Description: Represents code pages used in RTF.
*/
typedef enum
{
	CP_437,       // IBM Hoa Kỳ
	CP_708,       // Tiếng Ả Rập (ASMO 708)
	CP_709,       // Tiếng Ả Rập (ASMO 449+, BCON V4)
	CP_710,       // Tiếng Ả Rập (tiếng Ả Rập trong suốt)
	CP_711,       // Tiếng Ả Rập (Nafitha nâng cao)
	CP_720,       // Tiếng Ả Rập (ASMO trong suốt)
	CP_819,       // Windows 3.1 (Hoa Kỳ và Tây Âu)
	CP_850,       // IBM đa ngôn ngữ
	CP_852,       // Đông Âu
	CP_860,       // Tiếng Bồ Đào Nha
	CP_862,       // Tiếng Do Thái
	CP_863,       // Người Canada gốc Pháp
	CP_864,       // Tiếng Ả Rập
	CP_865,       // Người Na Uy
	CP_866,       // Liên Xô
	CP_932,       // Tiếng Nhật
	CP_1250,      // Windows 3.1 (Đông Âu)
	CP_1251       // Windows 3.1 (chữ Cyrillic)
} CodePage;

typedef struct
{
	int fontnum;			// \f
	FontFamily fontfamily;	// \fnil | \froman | \fswiss | \fmodern | \fscript | \fdecor | \ftech | \fbidi
	int fcharset;			// \fcharset
	string fprq;			// pitchRequest
	string panose;			// \data
	string nontaggedname;	// \*\fname
	string fontemb;			// '{\*' \fontemb <fonttype> <fontfname>? <data>? '}'
	CodePage cpg;			// \cpg
	string fontname;		// #PCDATA
	string fontaltname;		// '{\*' \falt #PCDATA '}'
} FONT;

typedef struct
{
	int red;
	int green;
	int blue;
} COLOR;

typedef struct save
{
	struct save* hNext;	

} SAVE;

struct Group
{
	string groupName;
	map<string, int> attributes;
	vector<Group> nestedGroups;

	Group(string name) : groupName(name) {}
};

//RTF Destination State
typedef enum	
{
	rdsNorm,	//Trạng thái bình thường (Normal).
	rdsSkip		//Trạng thái bỏ qua (Skip).
} RDS;

//RTF Internal State
typedef enum	
{
	risNorm,	//Trạng thái chuẩn (Normal).
	risBin,		//Trạng thái dữ liệu nhị phân (Binary Data).
	risHex		//Trạng thái dữ liệu hexa (Hexadecimal Data).
} RIS;


// Cấu trúc liệt kê thông tin RTF Control Word
typedef struct
{
	string keyword;
	int param;
	bool fParam;
} CTRLWORD;

enum ControlType
{
	Flag,			// Control word này sẽ bỏ qua mọi param
	Destination,	// Control word này bắt đầu một group hoặc đích. Nó bỏ qua bất kỳ param nào
	Symbol,			// Control word này đại diện cho một ký tự đặc biệt
	Toggle,			// Control word này dùng để phân biệt giữa trạng thái ON và OFF cho thuộc tính đã cho
	Value,			// Control word này yêu cầu một tham số
	Special,
	Skip,			// Skip qua các Control Word chưa update vào bảng TagList
};

const map<string, ControlType> TABLE_CTRLWORDS = {
{"'",				{ControlType::Symbol}},
{"-",				{ControlType::Symbol}},
{"*",				{ControlType::Symbol}},
{":",				{ControlType::Symbol}},
{"\\",				{ControlType::Symbol}},
{"_",				{ControlType::Symbol}},
{"{",				{ControlType::Symbol}},
{"|",				{ControlType::Symbol}},
{"}",				{ControlType::Symbol}},
{"~",				{ControlType::Symbol}},
{"rtf",				{ControlType::Destination}},
{"ansi",			{ControlType::Flag}},
{"ansicpg",			{ControlType::Value}},
{"deff",			{ControlType::Value}},
{"deflang",			{ControlType::Value}},
{"fonttbl",			{ControlType::Destination}},
{"colortbl",		{ControlType::Destination}},
{"red",				{ControlType::Value}},
{"green",			{ControlType::Value}},
{"blue",			{ControlType::Value}},
{"generator",		{ControlType::Special}},
{"f",				{ControlType::Value}},
{"fnil",			{ControlType::Flag}},
{"fcharset",		{ControlType::Value}},
{"viewkind",		{ControlType::Value}},
{"uc",				{ControlType::Value}},
{"pard",			{ControlType::Flag}},
{"sl",				{ControlType::Value}},
{"slmult",			{ControlType::Value}},
{"cf",				{ControlType::Value}},
{"ul",				{ControlType::Toggle}},
{"b",				{ControlType::Toggle}},
{"fs",				{ControlType::Value}},
{"lang",			{ControlType::Value}},
{"par",				{ControlType::Symbol}}
};