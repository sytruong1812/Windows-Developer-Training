﻿#include <iostream>
#include "RTFGroup.h"

bool RTFGroup::startGroup()
{
	//SAVE* hSaveNew = new SAVE;
	//if (hSaveNew == nullptr) {
	//	return false;
	//}
	//hSaveNew->hNext = hSave;
	////TODO: Lưu trạng thái hiện tại của Group
	//
	//hSave = hSaveNew;
	//nGroup++;

	return true;
}

bool RTFGroup::endGroup()
{
	//SAVE* hsaveOld;
	//if (!hSave) {
	//	return false;
	//}
	////TODO: Khôi phục trạng thái của Group

	//hsaveOld = hSave;
	//hSave = hSave->hNext;
	//nGroup--;
	//delete(hsaveOld);
	return true;
}
