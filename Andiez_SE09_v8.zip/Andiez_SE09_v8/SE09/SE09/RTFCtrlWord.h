#pragma once
#include "RTFType.h"
class RTFCtrlWord
{
private:
	CTRLWORD ctrlword;
protected:
	RDS rds;
	RIS ris;
	vector<CTRLWORD> ctrlwords;
public: 
	void saveKeyword(char* szKeyword, int param, bool fParam);
	void showKeyword(const vector<CTRLWORD>& ctrlwords);
	bool parseKeyword(const unsigned char* buffer, size_t &size, size_t &index);
	bool translateKeyword(char* szKeyword, int param, bool fParam);
	void translateTable(char* szKeyword, int param, bool fParam);
};