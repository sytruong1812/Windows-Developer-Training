#pragma once
#include <Windows.h>
#include "RTFFile.h"
#include "RTFGroup.h"

class RTFParse : public RTFGroup
{
private:
public:
	RTFParse();
	bool Parse(const unsigned char* buffer, size_t size);
};