#include "RTFFile.h"
#include "RTFParse.h"

using namespace std;

int main()
{
	RTFFile myFile;
	RTFParse myRTF;
	wstring path = L"C:\\Users\\home\\Downloads\\file.rtf";
	FileProcessError error;
	BYTE* buffer = nullptr;
	size_t size = 0;

	if (myFile.readFileRTF(path, buffer, size, error)) {
		if (!myRTF.Parse(buffer, size)) {
			cout << "Error parsing RTF" << endl;
		}
		else {
			cout << "Parsed RTF file successfully" << endl;
		}
	}
	else {
		cout << MessagesError[error].c_str() << endl;
	}
	return 0;
}


