#pragma once
#include <string>
#include <Windows.h>
#include <WinInet.h>

#define KB 1024
#define MB (1024 * 1024)
#define MAX_CONNECT 1;

using namespace std;

enum ERRORS
{
	NONE,
	INTERNET_INIT_ERROR,
	INTERNET_OPEN_ERROR,
	HTTP_404_CODE,
	HTTP_GET_INFO,
	NEW_BUFFER_FALSE,
	INTERNET_READ_FILE,
	OPEN_FILE_FALSE,
	WRITE_FILE_FALSE
};

const string Messages[] = {
	"No errors appear.",
	"Error unable to initialize Internet connection!",
	"Error unable to open Internet connection!",
	"Error could not find information requested by user!",
	"Error unable to get information from server!",
	"Error memory allocation failed!",
	"Error unable to read data from server!",
	"Error unable to opening output file!",
	"Error unable write data to file!"
};

bool downloadFileFromURL(const wstring& url, BYTE*& buffer, size_t& size, ERRORS& error);
bool saveFileFromBuffer(const wstring& outputFile, BYTE* buffer, size_t& sizeBuffer, ERRORS& error);