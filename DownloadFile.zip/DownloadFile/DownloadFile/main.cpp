#include <iostream>
#include "Download.h"
#include "AES_Crypt.h"

int wmain(int argc, const wchar_t* argv[])
{
	BYTE* buffer = nullptr;
	size_t sizeBuffer = 0;
	wstring url = argv[1];
	wstring outputFile = argv[2];
	ERRORS error;

	if (downloadFileFromURL(url, buffer, sizeBuffer, error) == false) {
		cout << Messages[error].c_str() << endl;
	}
	else {
		cout << "Download file success." << endl;
	}


	//BYTE szKey[] = "Key37";

	//AES aes(AESKeyLength::AES_128);
	//BYTE digest[16];						// Save value hash
	//BYTE iv[16];
	//BYTE newKey[32];
	//aes.generateIV(szKey, iv);				// Key -> Hash MD5 -> iv
	//aes.generateKey(szKey, newKey);			// Key -> Hash SHA256 -> newKey

	//size_t chunkEnd = 0;
	//size_t chunkSize = (10 * KB * KB);
	//size_t processedBytes = 0;
	//
	//MD5One(buffer, sizeBuffer, digest);

	//BYTE* saveBuffer = new BYTE[sizeBuffer];
	//if (saveBuffer == nullptr) {
	//	return false;
	//}
	//memset(saveBuffer, 0, sizeBuffer);	// Initialize the buffer with zeros
	//while (processedBytes < sizeBuffer) {
	//	chunkEnd = min(processedBytes + chunkSize, sizeBuffer);
	//	aes.decryptCBC(buffer + processedBytes, chunkEnd - processedBytes, newKey, iv, saveBuffer + processedBytes);
	//	processedBytes = chunkEnd;
	//}
	//aes.removePadding(saveBuffer, sizeBuffer);
	//if (saveBuffer != nullptr) {
	//	delete[] saveBuffer;
	//	saveBuffer = nullptr;
	//}

	if (buffer != nullptr) {
		delete[] buffer;
		buffer = nullptr;
	}
	return 0;
}